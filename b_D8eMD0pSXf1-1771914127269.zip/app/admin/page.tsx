"use client";

import {
  FileText,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Activity,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AdminToolsTable } from "@/components/admin/admin-tools-table";
import { AdminChart } from "@/components/admin/admin-chart";

const STATS = [
  {
    title: "Total Conversions",
    value: "128,432",
    change: "+12.5%",
    positive: true,
    icon: FileText,
  },
  {
    title: "Active Users",
    value: "4,892",
    change: "+8.2%",
    positive: true,
    icon: Users,
  },
  {
    title: "Revenue",
    value: "$23,456",
    change: "+18.7%",
    positive: true,
    icon: CreditCard,
  },
  {
    title: "Uptime",
    value: "99.98%",
    change: "-0.02%",
    positive: false,
    icon: Activity,
  },
];

export default function AdminDashboard() {
  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Overview of your PDFMaster Pro instance.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map((stat) => (
          <Card key={stat.title} className="gap-4 py-5">
            <CardHeader className="py-0">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <stat.icon className="size-4 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <div className="mt-1 flex items-center gap-1 text-xs">
                {stat.positive ? (
                  <ArrowUpRight className="size-3 text-accent" />
                ) : (
                  <ArrowDownRight className="size-3 text-destructive" />
                )}
                <span
                  className={
                    stat.positive ? "text-accent" : "text-destructive"
                  }
                >
                  {stat.change}
                </span>
                <span className="text-muted-foreground">from last month</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AdminChart />
        </div>
        <div>
          <AdminToolsTable />
        </div>
      </div>
    </div>
  );
}
