"use client";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const USERS = [
  { name: "Alex Johnson", email: "alex@example.com", plan: "Pro", conversions: 342, status: "active" },
  { name: "Maria Garcia", email: "maria@example.com", plan: "Free", conversions: 28, status: "active" },
  { name: "James Wilson", email: "james@example.com", plan: "Enterprise", conversions: 1205, status: "active" },
  { name: "Sarah Chen", email: "sarah@example.com", plan: "Pro", conversions: 567, status: "active" },
  { name: "David Kim", email: "david@example.com", plan: "Free", conversions: 12, status: "inactive" },
  { name: "Emma Brown", email: "emma@example.com", plan: "Pro", conversions: 189, status: "active" },
  { name: "Michael Lee", email: "michael@example.com", plan: "Free", conversions: 45, status: "active" },
  { name: "Lisa Wang", email: "lisa@example.com", plan: "Enterprise", conversions: 890, status: "active" },
];

export default function UsersPage() {
  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Users</h1>
        <p className="text-sm text-muted-foreground">
          Manage registered users and their subscriptions.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 mb-6">
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Total Users</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">4,892</p>
          </CardContent>
        </Card>
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Pro Subscribers</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">1,247</p>
          </CardContent>
        </Card>
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Enterprise</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">38</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Users</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th className="px-6 py-3 font-medium">User</th>
                  <th className="px-6 py-3 font-medium">Plan</th>
                  <th className="px-6 py-3 font-medium">Conversions</th>
                  <th className="px-6 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {USERS.map((user) => (
                  <tr key={user.email} className="border-b last:border-0">
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="size-8">
                          <AvatarFallback className="text-xs bg-primary/10 text-primary">
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-foreground">{user.name}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <Badge
                        variant={user.plan === "Enterprise" ? "default" : "secondary"}
                        className="text-xs"
                      >
                        {user.plan}
                      </Badge>
                    </td>
                    <td className="px-6 py-3 text-foreground">
                      {user.conversions.toLocaleString()}
                    </td>
                    <td className="px-6 py-3">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                          user.status === "active" ? "text-accent" : "text-muted-foreground"
                        }`}
                      >
                        <span
                          className={`size-1.5 rounded-full ${
                            user.status === "active" ? "bg-accent" : "bg-muted-foreground"
                          }`}
                        />
                        {user.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
