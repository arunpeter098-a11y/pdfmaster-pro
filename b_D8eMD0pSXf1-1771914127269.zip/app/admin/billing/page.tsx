"use client";

import { CreditCard, ArrowUpRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const TRANSACTIONS = [
  { id: "INV-001", user: "James Wilson", plan: "Enterprise", amount: "$29.00", date: "Feb 20, 2026", status: "Paid" },
  { id: "INV-002", user: "Sarah Chen", plan: "Pro", amount: "$9.00", date: "Feb 19, 2026", status: "Paid" },
  { id: "INV-003", user: "Alex Johnson", plan: "Pro", amount: "$9.00", date: "Feb 18, 2026", status: "Paid" },
  { id: "INV-004", user: "Emma Brown", plan: "Pro", amount: "$9.00", date: "Feb 17, 2026", status: "Pending" },
  { id: "INV-005", user: "Lisa Wang", plan: "Enterprise", amount: "$29.00", date: "Feb 16, 2026", status: "Paid" },
];

export default function BillingPage() {
  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Billing</h1>
        <p className="text-sm text-muted-foreground">
          Revenue overview and transaction history. Stripe integration ready.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 mb-6">
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Monthly Revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">$23,456</p>
            <div className="mt-1 flex items-center gap-1 text-xs text-accent">
              <ArrowUpRight className="size-3" />
              +18.7% from last month
            </div>
          </CardContent>
        </Card>
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Active Subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">1,285</p>
          </CardContent>
        </Card>
        <Card className="py-5 gap-4">
          <CardHeader className="py-0">
            <CardDescription>Avg. Revenue Per User</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">$18.25</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base">Payment Integration</CardTitle>
            <CardDescription>Connect Stripe for live payments</CardDescription>
          </div>
          <Button variant="outline" className="gap-2 rounded-xl">
            <CreditCard className="size-4" />
            Connect Stripe
          </Button>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-muted-foreground">
                  <th className="px-6 py-3 font-medium">Invoice</th>
                  <th className="px-6 py-3 font-medium">User</th>
                  <th className="px-6 py-3 font-medium">Plan</th>
                  <th className="px-6 py-3 font-medium">Amount</th>
                  <th className="px-6 py-3 font-medium">Date</th>
                  <th className="px-6 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {TRANSACTIONS.map((tx) => (
                  <tr key={tx.id} className="border-b last:border-0">
                    <td className="px-6 py-3 font-mono text-xs text-foreground">{tx.id}</td>
                    <td className="px-6 py-3 text-foreground">{tx.user}</td>
                    <td className="px-6 py-3">
                      <Badge variant="secondary" className="text-xs">{tx.plan}</Badge>
                    </td>
                    <td className="px-6 py-3 font-semibold text-foreground">{tx.amount}</td>
                    <td className="px-6 py-3 text-muted-foreground">{tx.date}</td>
                    <td className="px-6 py-3">
                      <Badge
                        variant={tx.status === "Paid" ? "default" : "secondary"}
                        className="text-xs"
                      >
                        {tx.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
