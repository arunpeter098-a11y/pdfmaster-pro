"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AdminChart } from "@/components/admin/admin-chart";
import { CATEGORIES } from "@/lib/tools-data";
import { ToolIcon } from "@/components/tool-icon";

const CATEGORY_STATS = [
  { category: "conversion", count: 52400, percentage: 41 },
  { category: "editing", count: 28900, percentage: 23 },
  { category: "security", count: 18200, percentage: 14 },
  { category: "organizing", count: 19800, percentage: 16 },
  { category: "advanced", count: 9100, percentage: 7 },
];

export default function AnalyticsPage() {
  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Analytics</h1>
        <p className="text-sm text-muted-foreground">
          Detailed usage statistics and insights.
        </p>
      </div>

      <AdminChart />

      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Usage by Category</CardTitle>
            <CardDescription>Distribution of tool usage across categories</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              {CATEGORY_STATS.map((stat) => {
                const cat = CATEGORIES.find((c) => c.id === stat.category);
                return (
                  <div key={stat.category} className="flex items-center gap-4">
                    <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10">
                      <ToolIcon name={cat?.icon || "FileText"} className="size-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-foreground">
                          {cat?.label}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {stat.count.toLocaleString()} uses
                        </span>
                      </div>
                      <div className="mt-1.5 h-2 w-full rounded-full bg-secondary">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${stat.percentage}%` }}
                        />
                      </div>
                    </div>
                    <span className="w-10 text-right text-sm font-semibold text-foreground">
                      {stat.percentage}%
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
