"use client";

import { useState } from "react";
import { Search, Crown } from "lucide-react";
import { TOOLS, CATEGORIES, type ToolCategory } from "@/lib/tools-data";
import { ToolIcon } from "@/components/tool-icon";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export default function AdminToolsPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<ToolCategory | "all">("all");

  const filtered = TOOLS.filter((t) => {
    const matchesSearch =
      !search.trim() ||
      t.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filter === "all" || t.category === filter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">
          Manage Tools
        </h1>
        <p className="text-sm text-muted-foreground">
          Enable, disable, and configure your PDF tools.
        </p>
      </div>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search tools..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="rounded-xl pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setFilter("all")}
            className={cn(
              "rounded-lg border px-3 py-1.5 text-xs font-medium transition-all",
              filter === "all"
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            All
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              className={cn(
                "rounded-lg border px-3 py-1.5 text-xs font-medium transition-all",
                filter === cat.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border bg-card">
        <div className="grid grid-cols-[1fr_auto_auto] items-center gap-4 border-b px-4 py-3 text-xs font-medium text-muted-foreground sm:grid-cols-[1fr_auto_auto_auto]">
          <span>Tool</span>
          <span className="hidden sm:block">Category</span>
          <span>Premium</span>
          <span>Enabled</span>
        </div>
        {filtered.map((tool) => (
          <div
            key={tool.id}
            className="grid grid-cols-[1fr_auto_auto] items-center gap-4 border-b px-4 py-3 last:border-0 sm:grid-cols-[1fr_auto_auto_auto]"
          >
            <div className="flex items-center gap-3">
              <div className="flex size-8 items-center justify-center rounded-lg bg-secondary">
                <ToolIcon name={tool.icon} className="size-4 text-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{tool.name}</p>
                <p className="text-xs text-muted-foreground line-clamp-1 max-w-xs">
                  {tool.description}
                </p>
              </div>
            </div>
            <Badge
              variant="secondary"
              className="hidden text-xs capitalize sm:inline-flex"
            >
              {tool.category}
            </Badge>
            <div className="flex justify-center">
              {tool.isPremium ? (
                <Crown className="size-4 text-primary" />
              ) : (
                <span className="text-xs text-muted-foreground">Free</span>
              )}
            </div>
            <Switch defaultChecked aria-label={`Toggle ${tool.name}`} />
          </div>
        ))}
      </div>
    </div>
  );
}
