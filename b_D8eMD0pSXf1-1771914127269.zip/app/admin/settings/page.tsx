"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function SettingsPage() {
  return (
    <div className="p-4 pt-4 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Configure your PDFMaster Pro instance.
        </p>
      </div>

      <div className="flex flex-col gap-6 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">General</CardTitle>
            <CardDescription>Basic site configuration</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div>
              <Label htmlFor="site-name">Site Name</Label>
              <Input id="site-name" defaultValue="PDFMaster Pro" className="mt-1.5 rounded-xl" />
            </div>
            <div>
              <Label htmlFor="site-desc">Site Description</Label>
              <Input
                id="site-desc"
                defaultValue="All-in-One Free PDF Toolkit"
                className="mt-1.5 rounded-xl"
              />
            </div>
            <div>
              <Label htmlFor="contact-email">Contact Email</Label>
              <Input
                id="contact-email"
                type="email"
                defaultValue="support@pdfmaster.pro"
                className="mt-1.5 rounded-xl"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Features</CardTitle>
            <CardDescription>Toggle application features</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-5">
            {[
              { label: "User Registration", description: "Allow new users to sign up", defaultChecked: true },
              { label: "Premium Features", description: "Enable premium tool features", defaultChecked: true },
              { label: "Blog", description: "Show the blog section", defaultChecked: true },
              { label: "Analytics Tracking", description: "Track tool usage analytics", defaultChecked: true },
              { label: "Maintenance Mode", description: "Show maintenance page to visitors", defaultChecked: false },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
                <Switch defaultChecked={item.defaultChecked} aria-label={item.label} />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Integrations</CardTitle>
            <CardDescription>Third-party service connections</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div>
              <Label htmlFor="firebase-key">Firebase API Key</Label>
              <Input
                id="firebase-key"
                type="password"
                placeholder="Enter your Firebase API key"
                className="mt-1.5 rounded-xl font-mono"
              />
            </div>
            <Separator />
            <div>
              <Label htmlFor="stripe-key">Stripe Secret Key</Label>
              <Input
                id="stripe-key"
                type="password"
                placeholder="sk_live_..."
                className="mt-1.5 rounded-xl font-mono"
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3">
          <Button variant="outline" className="rounded-xl">Cancel</Button>
          <Button className="rounded-xl">Save Changes</Button>
        </div>
      </div>
    </div>
  );
}
