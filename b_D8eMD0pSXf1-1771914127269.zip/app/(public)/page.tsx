import { HeroSection } from "@/components/hero-section";
import { FeaturesSection } from "@/components/features-section";
import { ToolsExplorer } from "@/components/tools-explorer";
import { CTASection } from "@/components/cta-section";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <FeaturesSection />
      <ToolsExplorer />
      <CTASection />
    </>
  );
}
