import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { ArrowLeft, Calendar, Clock, User } from "lucide-react";
import { BLOG_POSTS } from "@/lib/blog-data";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return BLOG_POSTS.map((post) => ({ slug: post.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = BLOG_POSTS.find((p) => p.slug === slug);
  if (!post) return {};
  return {
    title: post.title,
    description: post.excerpt,
  };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const post = BLOG_POSTS.find((p) => p.slug === slug);
  if (!post) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-12 lg:px-8 lg:py-16">
      <Link
        href="/blog"
        className="mb-8 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="size-3.5" />
        Back to blog
      </Link>

      <header className="mb-8">
        <span className="mb-3 inline-flex rounded-lg bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
          {post.category}
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
          {post.title}
        </h1>
        <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <User className="size-4" />
            {post.author}
          </span>
          <span className="flex items-center gap-1.5">
            <Calendar className="size-4" />
            {new Date(post.date).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="size-4" />
            {post.readTime}
          </span>
        </div>
      </header>

      <div className="prose prose-neutral dark:prose-invert max-w-none">
        <p className="text-lg leading-relaxed text-muted-foreground">{post.excerpt}</p>
        <div className="mt-8 space-y-6">
          <div className="rounded-2xl border bg-card p-6">
            <h2 className="text-xl font-bold text-foreground">Introduction</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Working with PDF files is an essential part of modern digital workflows.
              Whether you are a student, professional, or business owner, understanding
              how to efficiently manage your PDF documents can save you significant time
              and effort. In this guide, we will walk you through everything you need to know.
            </p>
          </div>
          <div className="rounded-2xl border bg-card p-6">
            <h2 className="text-xl font-bold text-foreground">Key Takeaways</h2>
            <ul className="mt-3 space-y-2">
              {[
                "Use the right tool for the right job",
                "Always keep a backup of your original files",
                "Consider file size when sharing documents",
                "Security should never be an afterthought",
              ].map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="mt-1.5 flex size-1.5 shrink-0 rounded-full bg-primary" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border bg-card p-6">
            <h2 className="text-xl font-bold text-foreground">Conclusion</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              By following the practices outlined in this guide, you can streamline your
              PDF workflows and ensure your documents are always professional, secure,
              and optimized. Try out PDFMaster Pro tools to put these tips into practice.
            </p>
          </div>
        </div>
      </div>
    </article>
  );
}
