"use client";

import Link from "next/link";
import { ArrowLeft, Crown } from "lucide-react";
import type { PDFTool } from "@/lib/tools-data";
import { ToolIcon } from "@/components/tool-icon";
import { ToolProcessor } from "@/components/tool-processor";
import { ToolCard } from "@/components/tool-card";
import { Badge } from "@/components/ui/badge";
import { CompressOptions } from "@/components/tool-options/compress-options";
import { MergeOptions } from "@/components/tool-options/merge-options";
import { WatermarkOptions } from "@/components/tool-options/watermark-options";
import { PasswordOptions } from "@/components/tool-options/password-options";
import { ConvertOptions } from "@/components/tool-options/convert-options";

function getToolOptions(slug: string) {
  switch (slug) {
    case "compress-pdf":
      return <CompressOptions />;
    case "merge-pdf":
    case "combine-pdfs":
      return <MergeOptions />;
    case "add-watermark":
      return <WatermarkOptions />;
    case "add-password":
    case "lock-pdf":
    case "encrypt-pdf":
      return <PasswordOptions />;
    case "pdf-to-word":
    case "pdf-to-excel":
    case "pdf-to-ppt":
    case "pdf-to-jpg":
    case "pdf-to-png":
      return <ConvertOptions />;
    default:
      return undefined;
  }
}

interface ToolPageClientProps {
  tool: PDFTool;
  categoryLabel: string;
  relatedTools: PDFTool[];
}

export function ToolPageClient({ tool, categoryLabel, relatedTools }: ToolPageClientProps) {
  const options = getToolOptions(tool.slug);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 lg:px-8 lg:py-12">
      {/* Breadcrumb */}
      <div className="mb-8">
        <Link
          href="/#tools"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-3.5" />
          Back to all tools
        </Link>
      </div>

      {/* Header */}
      <div className="mb-10 text-center">
        <div className="mx-auto mb-4 flex size-16 items-center justify-center rounded-2xl bg-primary/10">
          <ToolIcon name={tool.icon} className="size-8 text-primary" />
        </div>
        <div className="flex items-center justify-center gap-2">
          <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            {tool.name}
          </h1>
          {tool.isPremium && (
            <Badge className="gap-1 border-0 bg-primary/10 text-primary">
              <Crown className="size-3" />
              PRO
            </Badge>
          )}
        </div>
        <p className="mt-3 text-base text-muted-foreground">{tool.description}</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Category: {categoryLabel}
        </p>
      </div>

      {/* Processor */}
      <ToolProcessor tool={tool} options={options} />

      {/* How it works */}
      <div className="mx-auto mt-16 max-w-2xl">
        <h2 className="text-center text-xl font-bold text-foreground">How it works</h2>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-3">
          {[
            { step: "1", title: "Upload", desc: "Drop your file or click to browse" },
            { step: "2", title: "Process", desc: "We handle the heavy lifting for you" },
            { step: "3", title: "Download", desc: "Get your processed file instantly" },
          ].map((item) => (
            <div key={item.step} className="flex flex-col items-center gap-3 text-center">
              <div className="flex size-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                {item.step}
              </div>
              <h3 className="text-sm font-semibold text-foreground">{item.title}</h3>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Related Tools */}
      {relatedTools.length > 0 && (
        <div className="mt-16">
          <h2 className="mb-6 text-xl font-bold text-foreground">Related Tools</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {relatedTools.map((t) => (
              <ToolCard key={t.id} tool={t} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
