import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { TOOLS, getToolBySlug, getToolsByCategory, CATEGORIES } from "@/lib/tools-data";
import { ToolPageClient } from "./tool-page-client";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return TOOLS.map((tool) => ({ slug: tool.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const tool = getToolBySlug(slug);
  if (!tool) return {};
  return {
    title: `${tool.name} - Free Online Tool`,
    description: tool.description,
    openGraph: {
      title: `${tool.name} - PDFMaster Pro`,
      description: tool.description,
    },
  };
}

export default async function ToolPage({ params }: Props) {
  const { slug } = await params;
  const tool = getToolBySlug(slug);
  if (!tool) notFound();

  const category = CATEGORIES.find((c) => c.id === tool.category);
  const related = getToolsByCategory(tool.category)
    .filter((t) => t.id !== tool.id)
    .slice(0, 6);

  return <ToolPageClient tool={tool} categoryLabel={category?.label ?? ""} relatedTools={related} />;
}
